var express=require('express');
var app= express();
var bodyParser = require('body-parser');

//CONTROLLERS
var learningController=require('./controller/learningController');
var indexController=require('./controller/indexController');

var videoController=require('./controller/videoController');

//set template engine
app.set('view engine', 'ejs');
//app.use(bodyParser.urlencoded())
app.use(bodyParser.json());

 

//fire Controller
learningController(app);
indexController(app);

videoController(app);

app.use(express.static('./public'));

//listen to port 
app.listen(3000,function(){
    console.log(new Date());
});


