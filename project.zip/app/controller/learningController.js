var bodyParser = require("body-parser");
const fs = require("fs");

var urlencodedParser = bodyParser.urlencoded({ extended: false });



module.exports = function (app) {
  //get editor
  app.get('/api/', function (req, res) {
    fs.readFile("Index.json", 'utf8', function (err, fileData) {

      console.log(fileData);
    
      res.render('learning', { data: JSON.parse(fileData) });
      
    });
  });

























}